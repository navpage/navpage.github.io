Template by https://github.com/A3Bagged

Feel free to use these as a guideline.
Images used copyrighted to Material by Mkdocs

If this was helpfull please show some support :), Enjoy!